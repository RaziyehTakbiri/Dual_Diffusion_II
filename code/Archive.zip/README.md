# DMD — Dual-Manifold Diffusion (from-scratch pipeline)

Implements `paper/MODEL_SPEC.md` exactly. When math changes, the spec changes first, then the code.

## Layout

```
code/
  dmd/
    blocks/temporal.py    # B0–B5 ladder: ffn, ffn_timecond, gated_ffn, gru, cfc, node
    utils/params.py       # parameter matching (±1%) across ladder rungs
    data/                 # M2: MAESTRO/ASAP representation, IAM-OnDB, tabular adapters
    diffusion/            # M3: forward processes, schedules, objective
    models/               # M4: trunk (transformer + adaLN), heads, Gumbel bridge
    train/                # M5: Databricks/MLflow training harness
    sample/               # M6: DDIM + calibrated unmasking sampler
    eval/                 # M7: metrics suite (W1, ACF, conditional timing, Hellinger, FMD…)
    baselines/            # M8: jitter, AR (deterministic + distributional), SCHmUBERT-style, VQ-latent
  configs/                # YAML experiment configs (one file = one table row)
  tests/                  # CPU-runnable pytest; no GPU needed
```

## Build order (milestones)

- **M1 (done):** temporal block ladder + param matching + tests
- **M2:** music representation (ASAP grid, residuals, masks) + round-trip validator (E4.1/E4.2) + human-data ACF study (E4.3)
- **M3:** forward processes + objective (masked L_C, focal/elbo switch)
- **M4:** denoiser trunk + coupling
- **M5:** training harness (MLflow, seeds, DDP)
- **M6:** sampler (calibration-parity flag)
- **M7:** eval suite (jitter baselines E1.1 live here too — they're sampler-free)
- **M8:** baselines

## Databricks workflow

1. Copy `code/` to the workspace (or `pip install -e .` from a repo clone).
2. Single-node multi-GPU: `torchrun --nproc_per_node=<n> -m dmd.train.run --config configs/<name>.yaml --seed <s>`.
3. MLflow: each run logs config, matched param counts, git/spec version, metrics; export final metrics JSON to `results/<date>_<config>_<seed>.json` and drop into this folder for analysis.
4. Before any training run: `pytest tests/ -q` must pass on the driver (CPU).

## Conventions

- Every config field is read at most once, at startup; no hidden defaults in code.
- All randomness through a single seeded generator; seeds recorded in output filenames.
- All reported units follow MODEL_SPEC §2 (velocity ∈ [0,1]; timing in ms at metric time).
